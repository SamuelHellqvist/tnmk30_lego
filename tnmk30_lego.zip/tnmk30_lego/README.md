# tnmk30_lego
Detta är ett repository som ska innehålla alla filer till lösningen på lego-databas-uppgiften. Grupp 3, LIU 20022, tnmk30 elektronisk publicering
